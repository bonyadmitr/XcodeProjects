//
//  PhoneNumberKitExtentions.swift
//  OrderApp-Customer-iOS
//
//  Created by Yaroslav Bondar on 01.07.16.
//  Copyright © 2016 SMediaLink. All rights reserved.
//

// MARK: Need to import PhoneNumberKit framework to project

//import PhoneNumberKit
// TODO: "if let" or "guard let"
//extension PhoneNumberKit {
    //static var currentPhoneCode : UInt64 {
        //return PhoneNumberKit().codeForCountry(NSLocale.currentLanguageCode)!
    //}
//}