//
//  PromiseExtnetions.swift
//  OrderApp-Customer-iOS
//
//  Created by Yaroslav Bondar on 24.06.16.
//  Copyright © 2016 SMediaLink. All rights reserved.
//

// MARK: Need to import PromiseKit framework to project

//import UIKit
//import PromiseKit
//
//extension Promise {
//    func catchAndShow() {
//        self.error { (error) in
//            if let error = error as? Translatable {
//                UIAlertView(title: "Error", message: error.translated(locale: NSLocale(localeIdentifier: "EN")), delegate: nil, cancelButtonTitle: "OK").show()
//            }
//        }
//    }
//}