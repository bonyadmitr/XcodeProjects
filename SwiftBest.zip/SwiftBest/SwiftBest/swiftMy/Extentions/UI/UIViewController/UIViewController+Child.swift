//
//  UIViewController + Child.swift
//  MenuDrawer
//
//  Created by Yaroslav Bondar on 20.07.16.
//  Copyright © 2016 SMediaLink. All rights reserved.
//

import UIKit

extension UIViewController {

    //TODO: top layout guide
    
    // container must be view of UIViewController
    func addChildVC(vc: UIViewController, toContainer container: UIView) {
        addChildViewController(vc)
        vc.view.frame = container.bounds
        vc.view.layoutIfNeeded() //without animation
        container.addSubview(vc.view)
        vc.didMoveToParentViewController(self)
        
//        addChildViewController(vc)
//        container.addSubview(vc.view)
//        vc.view.translatesAutoresizingMaskIntoConstraints = false
//        vc.view.constrainEdges(toMarginOf: container)
//        vc.didMoveToParentViewController(self)
    }

    func addChildVC(vc: UIViewController) {
        addChildVC(vc, toContainer: self.view)
    }

    func addChildWithNavItem(vc: UIViewController, toContainer container: UIView) {
        addChildVC(vc, toContainer: container)
        // TODO: Settings for this !
        navigationItem.rightBarButtonItems = vc.navigationItem.rightBarButtonItems
        navigationItem.leftBarButtonItems = vc.navigationItem.leftBarButtonItems
        title = vc.title
    }

    func addChildVCWithNavItem(vc: UIViewController) {
        addChildWithNavItem(vc, toContainer: self.view)
    }
    
    
    // TODO: create removeFromContainer controller
    
    //remove
    func removeFromContainer() {
        willMoveToParentViewController(nil)
        view.removeFromSuperview()
        removeFromParentViewController()
    }
}

extension UIView {
    public func constrainEqual(attribute: NSLayoutAttribute, to: AnyObject, multiplier: CGFloat = 1, constant: CGFloat = 0) {
        constrainEqual(attribute, to: to, attribute, multiplier: multiplier, constant: constant)
    }
    
    public func constrainEqual(attribute: NSLayoutAttribute, to: AnyObject, _ toAttribute: NSLayoutAttribute, multiplier: CGFloat = 1, constant: CGFloat = 0) {
        NSLayoutConstraint.activateConstraints([
            NSLayoutConstraint(item: self, attribute: attribute, relatedBy: .Equal, toItem: to, attribute: toAttribute, multiplier: multiplier, constant: constant)
            ]
        )
    }
    
    public func constrainEdges(toMarginOf view: UIView) {
        constrainEqual(.Top, to: view, .Top)
        constrainEqual(.Leading, to: view, .Leading)
        constrainEqual(.Trailing, to: view, .Trailing)
        constrainEqual(.Bottom, to: view, .Bottom)
    }
    
    @available(iOS 9.0, *)
    public func center(inView view: UIView) {
        centerXAnchor.constrainEqual(view.centerXAnchor)
        centerYAnchor.constrainEqual(view.centerYAnchor)
    }
}

@available(iOS 9.0, *)
extension NSLayoutAnchor {
    public func constrainEqual(anchor: NSLayoutAnchor, constant: CGFloat = 0) {
        let constraint = constraintEqualToAnchor(anchor, constant: constant)
        constraint.active = true
    }
}
