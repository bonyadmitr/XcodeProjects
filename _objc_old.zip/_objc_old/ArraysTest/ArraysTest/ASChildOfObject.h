//
//  ASChildOfObject.h
//  ArraysTest
//
//  Created by zdaecqze zdaecq on 31.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASObject.h"

@interface ASChildOfObject : ASObject

@property (strong, nonatomic) NSString* lastName;

@end
