//
//  ASChildOfObject.m
//  ArraysTest
//
//  Created by zdaecqze zdaecq on 31.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASChildOfObject.h"

@implementation ASChildOfObject

-(void) Action
{
    NSLog(@"%@ CHILD ACTION!!!", self.name);
}

@end
