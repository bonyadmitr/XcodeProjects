//
//  ASObject.h
//  ArraysTest
//
//  Created by zdaecqze zdaecq on 31.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^BlockName)();

@interface ASObject : NSObject

@property (strong, nonatomic) NSString* name;

-(void) Action;


+(BlockName) block;
+(BlockName) block2: (NSString *) string;

@end
