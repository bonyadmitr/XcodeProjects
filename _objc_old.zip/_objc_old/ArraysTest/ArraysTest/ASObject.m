//
//  ASObject.m
//  ArraysTest
//
//  Created by zdaecqze zdaecq on 31.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASObject.h"

@implementation ASObject

-(void) Action
{
    NSLog(@"%@ ACTION!!!", self.name);
}

+(BlockName) block {
    return ^{ NSLog(@"block from class"); };
}

+(BlockName)block2: (NSString *) string {
    return ^{ NSLog(@"%@", string);};
}

@end
