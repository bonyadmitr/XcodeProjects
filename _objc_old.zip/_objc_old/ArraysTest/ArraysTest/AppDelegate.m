//
//  AppDelegate.m
//  ArraysTest
//
//  Created by zdaecqze zdaecq on 28.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "AppDelegate.h"
#import "ASObject.h"
#import "ASChildOfObject.h"

@interface AppDelegate ()

@property (nonatomic) int** myArray;

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    //NSArray* array = [[NSArray alloc] initWithObjects:@"String 1", @"String 2", @"String 3", nil];
    //NSArray* array = [NSArray arrayWithObjects:@"String 1", @"String 2", @"String 3", nil];
    //NSArray* array = @[@"String 1", @"String 2", @"String 3"];
    
    /*
    for (int i = 0; i < [array count]; i++) {
        NSLog(@"%@", [array objectAtIndex:i]);
    }
    
    for (int i = [array count] -1; i >= 0 ; i--) {
        NSLog(@"%@", [array objectAtIndex:i]);
    }
    
    
    for(NSString* string in array)
    {
        NSLog(@"%@", string);
        NSLog(@"Index = %lu", (unsigned long)[array indexOfObject:string]);
    }
    */
    
    ASObject* obj1 = [[ASObject alloc] init];
    ASObject* obj2 = [[ASObject alloc] init];
    ASChildOfObject* obj3 = [[ASChildOfObject alloc] init];
    
    
    
    obj1.name = @"Object 1";
    obj2.name = @"Object 2";
    [obj3 setName:@"Object 3"];
    [obj3 setLastName:@"Last name"];
    
    NSArray* array = [[NSArray alloc] initWithObjects:obj1, obj2, obj3, nil];
    
    for (ASObject* obj in array)
    {
        NSLog(@"name: %@", [obj name]);
        [obj Action];
        
        if ([obj isKindOfClass:[ASChildOfObject class]]) {
            ASChildOfObject* child = (ASChildOfObject*)obj;
            NSLog(@"Last name: %@", child.lastName);
        }
    }
    
    int N = 10000;
    //C arrays
    
    NSDate* methodStart = [NSDate date];
        
    int** D = malloc (N * sizeof (int *));
    
    for (int i=0; i<N; ++i) {
        D[i] = malloc (N * sizeof (int));
        for (int j=0; j<N; ++j)
            D[i][j] = 1;
    }
    
    /*
    NSString* string = @"";
    for (int i=0; i<N; ++i) {
        for (int j=0; j<N; ++j){
            string = [string stringByAppendingFormat:@"%d ", D[i][j]];
        }
        NSLog(@"%@\n", string);
        string = @"";
    }
    */
    
    NSDate* methodFinish = [NSDate date];
    NSTimeInterval executionTime = [methodFinish timeIntervalSinceDate:methodStart];
    NSLog(@"ExecutionTime 1 = %f", executionTime);
    
//    for (int i=0; i<N; i++)
//        free(D[i]);
//    free(D);
    
    //в памяти будет по порядку
    /*
     int** x;
     int* temp;
     
     x = malloc(N * sizeof(int*));
     temp = malloc(N * N * sizeof(int));
     for (int i = 0; i < N; i++) {
        x[i] = temp + (i * N);
     }
     
     free(temp);
     free(x);
     */
    
    
    methodStart = [NSDate date];
    
    
    NSInteger arraySize = 10;
    NSMutableArray* integerArray = [NSMutableArray arrayWithCapacity:arraySize];
    for (int i = 0; i < arraySize; i++){
        NSNumber* number = [NSNumber numberWithInteger:arc4random_uniform(100)];
        [integerArray addObject:number];
    }
    
    NSString* stringForArray = @"";
    for (int i = 0; i < arraySize; i++) {
        stringForArray = [stringForArray stringByAppendingFormat:@"%@ ", integerArray[i] ];
    }
    NSLog(@"%@", stringForArray);
    
    //сортировка массива
    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"self" ascending:YES];
    [integerArray sortUsingDescriptors:@[sort]];
    
    stringForArray = @"";
    for (int i = 0; i < arraySize; i++) {
        stringForArray = [stringForArray stringByAppendingFormat:@"%@ ", integerArray[i] ];
    }
    NSLog(@"%@", stringForArray);
    
    
    /*
    NSString* stringTest = @"";
    for (int i=0; i<N; ++i) {
        for (int j=0; j<N; ++j){
            stringTest = [stringTest stringByAppendingFormat:@"%d ", [arrayTest[i][j] integerValue]];
        }
        NSLog(@"%@\n", stringTest);
        stringTest = @"";
    }
    */
    
    methodFinish = [NSDate date];
    executionTime = [methodFinish timeIntervalSinceDate:methodStart];
    NSLog(@"ExecutionTime 2 = %f", executionTime);
    
    //----------------------------------------------------------------------------------------
    //getShuffleArrayFromArray
    
    NSInteger shuffleArrayCount = 10;
    NSMutableArray* shuffleArray = [NSMutableArray arrayWithCapacity:shuffleArrayCount];
    
    for (int i = 0 ; i < shuffleArrayCount; i++) {
        [shuffleArray addObject:@(i)];
    }
    
    //NSLog(@"%@", shuffleArray);
    
    for (int i = 0; i < shuffleArrayCount; i++) {
        NSInteger randomIndex = arc4random_uniform(shuffleArrayCount);
        [shuffleArray exchangeObjectAtIndex:i withObjectAtIndex:randomIndex];
    }
    
    //NSLog(@"%@", shuffleArray);
    
    
    
    [ASObject block2:@"123"];
    NSArray* array111 = [NSArray arrayWithObjects:
                         [ASObject block],
                         [ASObject block2:@"123"], nil];
    BlockName block = array111[0];
    BlockName block2 = array111[1];
    block();
    block2();
    

    return YES;
}

-(void) getExecutionTimeLogForBlock:(void (^)(void)) block {
    
    NSDate* methodStart = [NSDate date];
    
    block();
    
    NSDate* methodFinish = [NSDate date];
    NSTimeInterval executionTime = [methodFinish timeIntervalSinceDate:methodStart];
    NSLog(@"ExecutionTime = %f", executionTime);
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
