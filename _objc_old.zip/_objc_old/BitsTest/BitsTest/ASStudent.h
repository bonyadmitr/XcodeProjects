//
//  ASStudent.h
//  BitsTest
//
//  Created by zdaecqze zdaecq on 15.12.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum{
    ASStudentSubjectMath        = 1 << 0,
    ASStudentSubjectBiology     = 1 << 1,
    ASStudentSubjectHistory     = 1 << 2,
    ASStudentSubjectGeography   = 1 << 3
    
} ASStudentSubject;

@interface ASStudent : NSObject

@property (assign, nonatomic) ASStudentSubject subject;

@end
