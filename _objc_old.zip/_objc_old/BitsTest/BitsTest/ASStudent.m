//
//  ASStudent.m
//  BitsTest
//
//  Created by zdaecqze zdaecq on 15.12.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASStudent.h"

@implementation ASStudent

-(NSString*) subjectAnswer:(ASStudentSubject) subject
{
    return self.subject & subject ? @"Yes" : @"No";
}

- (NSString *)description
{
    return [NSString stringWithFormat:  @"Student studies:\n"
                                        "Math = %@\n"
                                        "Biology = %@\n"
                                        "History = %@\n"
                                        "Geography = %@",
                                        [self subjectAnswer:ASStudentSubjectMath],
                                        [self subjectAnswer:ASStudentSubjectBiology],
                                        [self subjectAnswer:ASStudentSubjectHistory],
                                        [self subjectAnswer:ASStudentSubjectGeography]
                                        ];
}

@end