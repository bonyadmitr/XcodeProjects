//
//  ViewController.h
//  ButtonsTest
//
//  Created by zdaecqze zdaecq on 14.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *testLable;
@property (weak, nonatomic) IBOutlet UILabel *labelInfo;

- (IBAction)OK:(UIButton*)sender;
- (IBAction)actionButtonImagePressedInside:(id)sender;

@end

