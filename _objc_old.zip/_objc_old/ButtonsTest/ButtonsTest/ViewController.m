//
//  ViewController.m
//  ButtonsTest
//
//  Created by zdaecqze zdaecq on 14.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) UIButton* testButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton* button1 = [UIButton buttonWithType:UIButtonTypeCustom];
    button1.backgroundColor = [UIColor greenColor];
    button1.frame = CGRectMake(50, 50, 150, 50);
    button1.tag = 3;
    
    /*
    // только с помощью атрибутов можно менять шрифт. можно добавлять тени и т.д.
    NSDictionary* titleAttributes = @{NSFontAttributeName: [UIFont systemFontOfSize:30],
                                     NSForegroundColorAttributeName: [UIColor blackColor]};
    NSAttributedString* title = [[NSAttributedString alloc] initWithString:@"BUTTON" attributes:titleAttributes];
    [button1 setAttributedTitle:title forState:UIControlStateNormal];

    
    NSDictionary* titleAttributesHighlighted = @{NSFontAttributeName: [UIFont systemFontOfSize:20],
                                      NSForegroundColorAttributeName: [UIColor grayColor]};
    NSAttributedString* titleHighlighted = [[NSAttributedString alloc]
                                            initWithString:@"BUTTON"
                                            attributes:titleAttributesHighlighted];
    [button1 setAttributedTitle:titleHighlighted forState:UIControlStateHighlighted];
    */

    // простая установка свойств
    [button1 setTitle:@"Button" forState:UIControlStateNormal];
    [button1 setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [button1 setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];

    
    // отступы внутри для текста кнопки
    UIEdgeInsets insets = UIEdgeInsetsMake(20, 20, 0, 0);
    button1.titleEdgeInsets = insets;
    
    //[self.view addSubview:button1];
    
    [button1 addTarget:self action:@selector(actionButtonTouchUpInside:) forControlEvents:UIControlEventTouchUpInside];
    [button1 addTarget:self action:@selector(actionButtonTouchDown:) forControlEvents:UIControlEventTouchDown];
    
    self.testButton = button1;
    [self.view addSubview:self.testButton];
    
}

#pragma mark - Actions

-(void) actionButtonTouchUpInside:(UIButton*)button{
    NSLog(@"Button pressed inside");
    self.testLable.text = [NSString stringWithFormat:@"%d",button.tag];
}

-(void) actionButtonTouchDown:(UIButton*)button{
    NSLog(@"Button pressed down");
}


- (IBAction)OK:(UIButton*)sender {
    
    NSLog(@"OK %d button pressed", sender.tag);
    
    self.testLable.text = [NSString stringWithFormat:@"%d",sender.tag];
    
    /*
    // не работает перерисовка
    self.testButton.center = CGPointMake(self.testButton.center.x + (arc4random() % 20 -10),
                                         self.testButton.center.y +  (arc4random() % 20 -10));
    [self.testButton setNeedsDisplay];
    //[self.testButton performSelector:@selector(setNeedsDisplay) withObject:nil afterDelay:0.2];
    [self.testButton performSelectorOnMainThread:@selector(setNeedsDisplay) withObject:nil waitUntilDone:NO];
    */
}

- (IBAction)actionButtonImagePressedInside:(id)sender {
    
    if ([self.labelInfo.text isEqualToString:@""]) {
        self.labelInfo.text = @"Button pressed";
    } else {
        self.labelInfo.text = @"";
    }
    
}
@end
