//
//  ViewController.h
//  Calculator
//
//  Created by zdaecqze zdaecq on 15.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum{
    ASOperationSignClear = 0,
    ASOperationSignAddition,
    ASOperationSignSubtraction,
    ASOperationSignMultiplication,
    ASOperationSignDivision
} ASOperationSign;

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *displayLabel;

- (IBAction)actionButtonAnyDigitTouchUpInside:(UIButton*)sender;
- (IBAction)actionButtonAddPoint:(id)sender;

- (IBAction)actionButtonEquals:(id)sender;
- (IBAction)actionButtonAddition:(id)sender;
- (IBAction)actionButtonSubtraction:(id)sender;
- (IBAction)actionButtonMultiplication:(id)sender;
- (IBAction)actionButtonDivision:(id)sender;
- (IBAction)actionButtonDelete:(id)sender;
- (IBAction)actionButtonClear:(id)sender;
- (IBAction)actionButtonClearAll:(id)sender;

@end

