//
//  ViewController.m
//  Calculator
//
//  Created by zdaecqze zdaecq on 15.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property(assign,nonatomic) CGFloat lastInput;
@property(assign,nonatomic) CGFloat lastInputForEquals;
@property(assign,nonatomic) ASOperationSign operationSign;
@property(assign,nonatomic) BOOL clearFlag;
@property(assign,nonatomic) BOOL calculateFlag;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.calculateFlag = NO;
    self.clearFlag = NO;
    self.lastInput = 0;
}

#pragma mark - Private methods

-(void) calculateResult{
    
        CGFloat lableNumber = 0;
    
        if (self.lastInputForEquals == 0) {
            lableNumber = [self.displayLabel.text floatValue];
            self.lastInputForEquals = lableNumber;
        } else {
            lableNumber = self.lastInputForEquals;
        }
        
        CGFloat result = 0;
    
        if (self.operationSign == ASOperationSignAddition) {
            result = self.lastInput + lableNumber;
        } else if (self.operationSign == ASOperationSignSubtraction) {
            result = self.lastInput - lableNumber;
        } else if (self.operationSign == ASOperationSignMultiplication) {
            result = self.lastInput * lableNumber;
        } else if (self.operationSign == ASOperationSignDivision) {
            result = self.lastInput / lableNumber;
        }
    
        self.displayLabel.text = [[NSNumber numberWithFloat:result] stringValue];
        self.lastInput = result;
        self.clearFlag = YES;
        self.calculateFlag = NO;
}

-(void) makeOperation{
    // чтобы обнулялось после нажатия клавиши равно, ввода числа и затем знака
    if (self.lastInputForEquals != 0) {
        self.lastInput = 0;
    }
    
    if (self.lastInput != 0 && self.calculateFlag == YES) {
        [self calculateResult];
        self.calculateFlag = NO;
    } else {
        self.lastInput = [self.displayLabel.text floatValue];
    }
    self.lastInputForEquals = 0;
    self.clearFlag = YES;
}


#pragma mark - Actions number buttons


- (IBAction)actionButtonAnyDigitTouchUpInside:(UIButton*)sender{

    if ([self.displayLabel.text isEqualToString:@"0"]) {
        self.displayLabel.text = @"";
    }
    
    if (self.clearFlag == YES){
        self.displayLabel.text = @"";
        self.clearFlag = NO;
        self.calculateFlag = YES;
    }
    
    self.displayLabel.text = [self.displayLabel.text stringByAppendingString:sender.titleLabel.text];
}

- (IBAction)actionButtonAddPoint:(id)sender {
    
    // отдельно пишем метод т.к. при обнулении нам нужно прописывать два знака "0."
    // а постоянно проверять на ввод точки не производительно
    
    if (self.clearFlag == YES){
        self.displayLabel.text = @"0";
        self.clearFlag = NO;
    }
    
    self.displayLabel.text = [self.displayLabel.text stringByAppendingString:@"."];
    
    //[self addLableDigit:@"."];
}

#pragma mark - Actions operation buttons

- (IBAction)actionButtonEquals:(id)sender {
    [self calculateResult];
}

- (IBAction)actionButtonAddition:(id)sender {
    
    [self makeOperation];
    self.operationSign = ASOperationSignAddition;
}

- (IBAction)actionButtonSubtraction:(id)sender {
    
    [self makeOperation];
    self.operationSign = ASOperationSignSubtraction;
}

- (IBAction)actionButtonMultiplication:(id)sender {
    
    [self makeOperation];
    self.operationSign = ASOperationSignMultiplication;
}

- (IBAction)actionButtonDivision:(id)sender {
    
    [self makeOperation];
    self.operationSign = ASOperationSignDivision;
}

- (IBAction)actionButtonDelete:(id)sender {
    NSString* lableText = self.displayLabel.text;
    
    if ([lableText length] > 1){
        self.displayLabel.text = [lableText substringToIndex:[lableText length]-1];
    } else {
        self.displayLabel.text = @"0";
    }
    
    // чтобы работало когда заного нажать кнопку равно
    if (self.lastInputForEquals != 0) {
        self.lastInput = [self.displayLabel.text floatValue];
    }
}

- (IBAction)actionButtonClear:(id)sender {
    self.displayLabel.text = @"0";
    
    // чтобы работало когда заного нажать кнопку равно
    if (self.lastInputForEquals != 0) {
        self.lastInput = 0;
    }
}

- (IBAction)actionButtonClearAll:(id)sender {
    self.lastInput = 0;
    self.displayLabel.text = @"0";
    self.clearFlag = NO;
    self.operationSign = ASOperationSignClear;
    
    self.lastInputForEquals = 0;
}
@end
