//
//  ViewController.h
//  Calculator
//
//  Created by zdaecqze zdaecq on 15.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum{
    ASOperationSignVoid = 0,
    ASOperationSignAddition,
    ASOperationSignSubtraction,
    ASOperationSignMultiplication,
    ASOperationSignDivision
} ASOperationSign;

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *displayLabel;

- (IBAction)actionButtonAddZero:(id)sender;
- (IBAction)actionButtonAddPoint:(id)sender;
- (IBAction)actionButtonAddOne:(id)sender;
- (IBAction)actionButtonAddTwo:(id)sender;
- (IBAction)actionButtonAddThree:(id)sender;
- (IBAction)actionButtonAddFour:(id)sender;
- (IBAction)actionButtonAddFive:(id)sender;
- (IBAction)actionButtonAddSix:(id)sender;
- (IBAction)actionButtonAddSeven:(id)sender;
- (IBAction)actionButtonAddEight:(id)sender;
- (IBAction)actionButtonAddNine:(id)sender;

- (IBAction)actionButtonEquals:(id)sender;
- (IBAction)actionButtonAddition:(id)sender;
- (IBAction)actionButtonSubtraction:(id)sender;
- (IBAction)actionButtonMultiplication:(id)sender;
- (IBAction)actionButtonDivision:(id)sender;
- (IBAction)actionButtonDelete:(id)sender;
- (IBAction)actionButtonClear:(id)sender;
- (IBAction)actionButtonClearAll:(id)sender;

@end

