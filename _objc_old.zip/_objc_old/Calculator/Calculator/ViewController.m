//
//  ViewController.m
//  Calculator
//
//  Created by zdaecqze zdaecq on 15.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property(assign,nonatomic) CGFloat lastInput;
@property(assign,nonatomic) ASOperationSign operationSign;
@property(assign,nonatomic) BOOL clearFlag;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

#pragma mark - Private methods

-(void) addLableDigit:(NSString*)digit{
    
    //NSString* lableText = self.displayLabel.text;
    
    if ([self.displayLabel.text isEqualToString:@"0"]) {
        self.displayLabel.text = @"";
        
    } else if (self.clearFlag == YES){
        self.displayLabel.text = @"";
        self.clearFlag = NO;
    }
    self.displayLabel.text = [self.displayLabel.text stringByAppendingString:digit];
}

-(void) calculateResult{
    
    // проверка на первый ввод и на ввод после нажания на знак равно
    if (self.lastInput == 0) {
        self.lastInput = [self.displayLabel.text floatValue];
        self.clearFlag = TRUE;
        
    } else {
        CGFloat lableNumber = [self.displayLabel.text floatValue];
        CGFloat result = 0;
        
        if (self.operationSign == ASOperationSignAddition) {
            result = self.lastInput + lableNumber;
        } else if (self.operationSign == ASOperationSignSubtraction) {
            result = self.lastInput - lableNumber;
        } else if (self.operationSign == ASOperationSignMultiplication) {
            result = self.lastInput * lableNumber;
        } else if (self.operationSign == ASOperationSignDivision) {
            result = self.lastInput / lableNumber;
        }
        
        //self.displayLabel.text = [NSString stringWithFormat:@"%f", result];
        self.displayLabel.text = [[NSNumber numberWithFloat:result] stringValue];
        self.lastInput = result;
        self.clearFlag = TRUE;
    }
}

#pragma mark - Actions number buttons

- (IBAction)actionButtonAddZero:(id)sender {
    [self addLableDigit:@"0"];
}

- (IBAction)actionButtonAddPoint:(id)sender {
    
    // отдельно пишем метод т.к. при обнулении нам нужно прописывать два знака "0."
    // а постоянно проверять на ввод точки не производительно
    
    if (self.clearFlag == YES){
        self.displayLabel.text = @"0";
        self.clearFlag = NO;
    }
    
    self.displayLabel.text = [self.displayLabel.text stringByAppendingString:@"."];
    
    //[self addLableDigit:@"."];
}

- (IBAction)actionButtonAddOne:(id)sender {
    [self addLableDigit:@"1"];
}

- (IBAction)actionButtonAddTwo:(id)sender {
    [self addLableDigit:@"2"];
}

- (IBAction)actionButtonAddThree:(id)sender {
    [self addLableDigit:@"3"];
}

- (IBAction)actionButtonAddFour:(id)sender {
    [self addLableDigit:@"4"];
}

- (IBAction)actionButtonAddFive:(id)sender {
    [self addLableDigit:@"5"];
}

- (IBAction)actionButtonAddSix:(id)sender {
    [self addLableDigit:@"6"];
}

- (IBAction)actionButtonAddSeven:(id)sender {
    [self addLableDigit:@"7"];
}

- (IBAction)actionButtonAddEight:(id)sender {
    [self addLableDigit:@"8"];
}

- (IBAction)actionButtonAddNine:(id)sender {
    [self addLableDigit:@"9"];
}

#pragma mark - Actions operation buttons

- (IBAction)actionButtonEquals:(id)sender {
    [self calculateResult];
    //self.lastInput = 0;
}

- (IBAction)actionButtonAddition:(id)sender {
    
    [self calculateResult];
    self.operationSign = ASOperationSignAddition;
}

- (IBAction)actionButtonSubtraction:(id)sender {
    
    [self calculateResult];
    self.operationSign = ASOperationSignSubtraction;
}

- (IBAction)actionButtonMultiplication:(id)sender {
    
    [self calculateResult];
    self.operationSign = ASOperationSignMultiplication;
}

- (IBAction)actionButtonDivision:(id)sender {
    
    [self calculateResult];
    self.operationSign = ASOperationSignDivision;
}

- (IBAction)actionButtonDelete:(id)sender {
    NSString* lableText = self.displayLabel.text;
    
    if ([lableText length] > 1){
        self.displayLabel.text = [lableText substringToIndex:[lableText length]-1];
    } else {
        self.displayLabel.text = @"0";
    }
}

- (IBAction)actionButtonClear:(id)sender {
    self.displayLabel.text = @"0";
}

- (IBAction)actionButtonClearAll:(id)sender {
    self.lastInput = 0;
    self.displayLabel.text = @"0";
    self.clearFlag = NO;
}
@end
