//
//  ViewController.h
//  ContrlosTest
//
//  Created by zdaecqze zdaecq on 17.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UISlider *sliderColorComponentOne;
@property (weak, nonatomic) IBOutlet UISlider *sliderColorComponentTwo;
@property (weak, nonatomic) IBOutlet UISlider *sliderColorComponentThree;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedControlColorType;
@property (weak, nonatomic) IBOutlet UIView *viewColorTest;
@property (weak, nonatomic) IBOutlet UILabel *labelTestDisaplay;

- (IBAction)actionSliderValueChanged:(UISlider*)sender;
- (IBAction)actionSwitchChanged:(UISwitch *)sender;
- (IBAction)actionSementedControlValueChanged:(UISegmentedControl*)sender;
- (IBAction)actionButtonAnyTouchedInside:(UIButton*)sender;

@end

