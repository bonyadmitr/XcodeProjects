//
//  ViewController.m
//  ContrlosTest
//
//  Created by zdaecqze zdaecq on 17.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"

typedef enum{
    ASColorTypeRGB,
    ASColorTypeHSV
} ASColorType;

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setBackgroundColorToView:self.viewColorTest];
}

#pragma mark - Private methods

-(void) setBackgroundColorToView:(UIView*) view{
    CGFloat componentOne =  self.sliderColorComponentOne.value;
    CGFloat componentTwo =  self.sliderColorComponentTwo.value;
    CGFloat componentThree =  self.sliderColorComponentThree.value;
    
    UIColor* color = nil;
    if (self.segmentedControlColorType.selectedSegmentIndex == ASColorTypeRGB) {
        color = [UIColor colorWithRed:componentOne green:componentTwo blue:componentThree alpha:1];
    } else {
        color = [UIColor colorWithHue:componentOne saturation:componentTwo brightness:componentThree alpha:1];
    }
    
    view.backgroundColor = color;
}

#pragma mark - Actions

- (IBAction)actionSliderValueChanged:(UISlider*)sender {
    //NSLog(@"%0.2f, %0.2f, %0.2f", self.sliderColorComponentOne.value, self.sliderColorComponentTwo.value, self.sliderColorComponentThree.value );
    [self setBackgroundColorToView:self.viewColorTest];
}

- (IBAction)actionSwitchChanged:(UISwitch *)sender {
    self.sliderColorComponentOne.enabled = self.sliderColorComponentTwo.enabled = self.sliderColorComponentThree.enabled = sender.isOn;
}

- (IBAction)actionSementedControlValueChanged:(UISegmentedControl*)sender {
    
    CGFloat componentOne;
    CGFloat componentTwo;
    CGFloat componentThree;
    CGFloat componentFour;

    
    UIColor* color = self.viewColorTest.backgroundColor;
    
    if (sender.selectedSegmentIndex == ASColorTypeRGB) {
        [color getRed:&componentOne green:&componentTwo blue:&componentThree alpha:&componentFour];
    } else {
        [color getHue:&componentOne saturation:&componentTwo brightness:&componentThree alpha:&componentFour];
    }
    
    self.sliderColorComponentOne.value = componentOne;
    self.sliderColorComponentTwo.value = componentTwo;
    self.sliderColorComponentThree.value = componentThree;
}

- (IBAction)actionButtonAnyTouchedInside:(UIButton*)sender{
    if ([self.labelTestDisaplay.text isEqualToString:@"0"]) {
        self.labelTestDisaplay.text = @"";
        
    }
    self.labelTestDisaplay.text = [self.labelTestDisaplay.text stringByAppendingString:sender.titleLabel.text];
}
@end
