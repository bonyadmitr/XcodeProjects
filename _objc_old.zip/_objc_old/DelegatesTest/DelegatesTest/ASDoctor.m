//
//  ASDoctor.m
//  DelegatesTest
//
//  Created by zdaecqze zdaecq on 15.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASDoctor.h"


@implementation ASDoctor

#pragma mark - ASPatientDelegate

-(void) patientFeelsBad:(ASPatient*) patient
{
    NSLog(@"patient %@ feels bad", patient.name);
    
    if (patient.temperature >= 37.f && patient.temperature <= 39.f) {
        [patient takePill];
    } else if (patient.temperature > 39.f) {
        [patient makeShot];
    } else {
        NSLog(@"patient %@ should rest", patient.name);
    }
}

-(void) patient:(ASPatient*)patient hasQuestion: (NSString*) question
{
    NSLog(@"patient %@ has a question: %@", patient.name, question);
}

@end
