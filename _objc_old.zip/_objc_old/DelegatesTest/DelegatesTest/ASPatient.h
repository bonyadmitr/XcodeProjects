//
//  ASPatient.h
//  DelegatesTest
//
//  Created by zdaecqze zdaecq on 15.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol ASPatientDelegate;
@interface ASPatient : NSObject

@property (strong, nonatomic) NSString* name;
@property (assign, nonatomic) float temperature;
@property (weak, nonatomic) id <ASPatientDelegate> delegate;

-(BOOL) howAreYou;
-(void) takePill;
-(void) makeShot;

@end

@protocol ASPatientDelegate <NSObject>

@required
-(void) patientFeelsBad:(ASPatient*) patient;
-(void) patient:(ASPatient*)patient hasQuestion: (NSString*) question;

@end