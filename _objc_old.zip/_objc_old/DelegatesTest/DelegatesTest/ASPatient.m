//
//  ASPatient.m
//  DelegatesTest
//
//  Created by zdaecqze zdaecq on 15.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASPatient.h"

@implementation ASPatient

-(BOOL) howAreYou
{
    BOOL iFeelGood = NO;
    
    if (!iFeelGood) {
        [self.delegate patientFeelsBad:self];
    }
    return iFeelGood;
}

-(void) takePill
{
    NSLog(@"%@ takes pill", self.name);
}

-(void) makeShot
{
    NSLog(@"%@ make shot", self.name);
}

@end
