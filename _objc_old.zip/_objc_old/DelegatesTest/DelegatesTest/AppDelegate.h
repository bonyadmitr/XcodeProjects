//
//  AppDelegate.h
//  DelegatesTest
//
//  Created by zdaecqze zdaecq on 15.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

