//
//  ZZClass.h
//  DetailTest
//
//  Created by zdaecqze zdaecq on 10.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZZClass : NSObject

@property (strong, nonatomic) NSString* className;
@property (strong, nonatomic) NSString* teacherName;
@property (strong, nonatomic) NSString* timeIn;
@property (strong, nonatomic) NSString* timeOut;

+(ZZClass*) emptyClass;


@end
