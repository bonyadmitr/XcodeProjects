//
//  ZZClass.m
//  DetailTest
//
//  Created by zdaecqze zdaecq on 10.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ZZClass.h"

@implementation ZZClass

+(ZZClass*) emptyClass{
    
    ZZClass* class = [[ZZClass alloc] init];
    class.className = @"Class name";
    class.teacherName = @"Teacher name";
    class.timeIn = @"10:00";
    class.timeOut = @"11:30";
    
    return class;
    
}


@end
