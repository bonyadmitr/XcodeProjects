//
//  ZZClassCell.h
//  DetailTest
//
//  Created by zdaecqze zdaecq on 10.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZZClassCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *className;
@property (weak, nonatomic) IBOutlet UILabel *teacherName;
@property (weak, nonatomic) IBOutlet UILabel *timeIn;
@property (weak, nonatomic) IBOutlet UILabel *timeOut;


@end
