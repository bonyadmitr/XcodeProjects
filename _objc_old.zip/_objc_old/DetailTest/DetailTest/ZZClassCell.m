//
//  ZZClassCell.m
//  DetailTest
//
//  Created by zdaecqze zdaecq on 10.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ZZClassCell.h"

@implementation ZZClassCell

@end
