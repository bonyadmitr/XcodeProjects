//
//  ViewController.h
//  DetailTest
//
//  Created by zdaecqze zdaecq on 10.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZZClass.h"

@interface ZZDetailViewController : UIViewController

@property (strong, nonatomic) ZZClass* setClass;

@property (weak, nonatomic) IBOutlet UITextField *textFieldClassName;
@property (weak, nonatomic) IBOutlet UITextField *textFieldTeacherName;

@end

