//
//  ViewController.m
//  DetailTest
//
//  Created by zdaecqze zdaecq on 10.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ZZDetailViewController.h"
#import "ZZTableViewController.h"
#import "ZZClass.h"


@interface ZZDetailViewController () 

@end

@implementation ZZDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    if (self.setClass) {
        self.textFieldClassName.text = self.setClass.className;
        self.textFieldTeacherName.text = self.setClass.teacherName;
    }
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    if (self.isMovingFromParentViewController) {
        
        ZZTableViewController* controller = (ZZTableViewController*)self.navigationController.topViewController;
        
        ZZClass* class = [[ZZClass alloc] init];
        class.className = self.textFieldClassName.text;
        class.teacherName = self.textFieldTeacherName.text;
        class.timeIn = @"11:11";
        class.timeOut = @"22:22";
        
        controller.setCellClass = class;
        
        NSIndexPath *indexPath = [controller.tableView indexPathForSelectedRow];
        controller.setCellIndex = indexPath.row;
    }

}





















@end
