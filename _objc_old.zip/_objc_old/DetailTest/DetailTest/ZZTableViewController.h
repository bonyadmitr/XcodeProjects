//
//  ZZTableViewController.h
//  DetailTest
//
//  Created by zdaecqze zdaecq on 10.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZZClass.h"

@interface ZZTableViewController : UITableViewController <UITableViewDataSource, UITableViewDelegate>

@property (strong, nonatomic) NSMutableArray* classesArray;
@property (strong, nonatomic) ZZClass* setCellClass;
@property (assign, nonatomic) NSInteger setCellIndex;

- (IBAction)actionAddClassCell:(UIBarButtonItem *)sender;

@end
