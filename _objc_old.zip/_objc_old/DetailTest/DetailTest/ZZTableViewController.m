//
//  ZZTableViewController.m
//  DetailTest
//
//  Created by zdaecqze zdaecq on 10.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ZZTableViewController.h"
#import "ZZClassCell.h"

#import "ZZDetailViewController.h"

@interface ZZTableViewController ()

@end


@implementation ZZTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.classesArray = [NSMutableArray array];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    if (self.setCellClass) {
        self.classesArray[self.setCellIndex] = self.setCellClass;
        [self.tableView reloadData];
    }
}

#pragma mark - Actions

- (IBAction)actionAddClassCell:(UIBarButtonItem *)sender {
    
    ZZClass* class = [ZZClass emptyClass];
    [self.classesArray insertObject:class atIndex:0];
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];

    
    [self.tableView beginUpdates];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];
    [self.tableView endUpdates];
}

#pragma mark - Segues

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier  isEqualToString:@"showDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        ZZClass* class = self.classesArray[indexPath.row];
        
        ZZDetailViewController *controller = (ZZDetailViewController *)segue.destinationViewController;
        controller.setClass = class;
    }
}


#pragma mark - TableView
//UITableViewDelegate
//UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return self.classesArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    ZZClassCell* cell = [tableView dequeueReusableCellWithIdentifier:@"ClassCell"];
    
    ZZClass* class = self.classesArray[indexPath.row];
    
    cell.className.text = class.className;
    cell.teacherName.text = class.teacherName;
    cell.timeIn.text = class.timeIn;
    cell.timeOut.text = class.timeOut;
    
    return cell;
}
















@end
