//
//  ZZClass.m
//  DetailTest
//
//  Created by zdaecqze zdaecq on 10.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ZZClass.h"

NSString* ZZClassKeyClassName = @"className";
NSString* ZZClassKeyTeacherName = @"teacherName";
NSString* ZZClassKeyTimeIn = @"timeIn";
NSString* ZZClassKeyTimeOut = @"timeOut";

@implementation ZZClass

+(ZZClass*) emptyClass{
    
    ZZClass* class = [[ZZClass alloc] init];
    class.className = @"Class name";
    class.teacherName = @"Teacher name";
    class.timeIn = @"10:00";
    class.timeOut = @"11:30";
    
    return class;
    
}


- (void) encodeWithCoder:(NSCoder *)coder {
    
    [coder encodeObject:self.className forKey:ZZClassKeyClassName];
    [coder encodeObject:self.teacherName forKey:ZZClassKeyTeacherName];
    [coder encodeObject:self.timeIn forKey:ZZClassKeyTimeIn];
    [coder encodeObject:self.timeOut forKey:ZZClassKeyTimeOut];
}


- (id)initWithCoder:(NSCoder *)coder {
    
    self.className = [coder decodeObjectForKey:ZZClassKeyClassName];
    self.teacherName = [coder decodeObjectForKey:ZZClassKeyTeacherName];
    self.timeIn = [coder decodeObjectForKey:ZZClassKeyTimeIn];
    self.timeOut = [coder decodeObjectForKey:ZZClassKeyTimeOut];
    
    return self;
}


@end
