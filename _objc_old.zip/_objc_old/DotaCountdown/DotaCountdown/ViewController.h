//
//  ViewController.h
//  DotaCountdown
//
//  Created by zdaecqze zdaecq on 15.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *startButton;
@property (weak, nonatomic) IBOutlet UISegmentedControl *levelSegmentControl;
@property (weak, nonatomic) IBOutlet UILabel *nameOfHero;
@property (weak, nonatomic) IBOutlet UIButton *aganimButton;
@property (weak, nonatomic) IBOutlet UIButton *octarinButton;

@end

