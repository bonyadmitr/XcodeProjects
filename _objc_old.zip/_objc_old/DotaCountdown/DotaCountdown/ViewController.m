//
//  ViewController.m
//  DotaCountdown
//
//  Created by zdaecqze zdaecq on 15.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <AVFoundation/AVFoundation.h>
#import "ViewController.h"

@interface ViewController ()

@property (strong, nonatomic) NSTimer* timer;
@property (assign, nonatomic) NSInteger seconds;

@property (strong, nonatomic) AVAudioPlayer* audioPlayer;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //self.timer = [NSTimer];
    
    self.startButton.titleLabel.shadowOffset = CGSizeMake(2, 2);
    
    [self.startButton addTarget:self action:@selector(actionStartButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.aganimButton addTarget:self action:@selector(actionAganimButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.octarinButton addTarget:self action:@selector(actionOctarinButton:) forControlEvents:UIControlEventTouchUpInside];
    [self.levelSegmentControl addTarget:self action:@selector(actionLevelChanged:) forControlEvents:UIControlEventValueChanged];
    
}
#pragma mark - Methods

-(void) changeStartButtonText {
    
    NSInteger value = 0;
    
    if (self.aganimButton.isSelected) {
        value = 70;
    } else if (self.levelSegmentControl.selectedSegmentIndex == 0) {
        value = 130;
    } else if (self.levelSegmentControl.selectedSegmentIndex == 1) {
        value = 120;
    } else if (self.levelSegmentControl.selectedSegmentIndex == 2) {
        value = 110;
    }
    
    if (self.octarinButton.isSelected) {
        value = value * 75 / 100;
    }
    
    NSString* result = [NSString stringWithFormat:@"%ld", (long)value];
    
    
    if (!self.startButton.isSelected) {
        [self.startButton setTitle:result forState: UIControlStateHighlighted];
        [self.startButton setTitle:result forState: UIControlStateNormal];
        [self.startButton setTitle:result forState: UIControlStateSelected];
    }
    
}

#pragma mark - Actions

//нажатие на кнопку старта
- (void) actionStartButton:(UIButton*)sender{
    sender.selected = !sender.selected;
    
    if (sender.selected) {
        [self start];
    } else {
        [self.timer invalidate];
        [self changeStartButtonText];
    }
}

- (void) actionAganimButton:(UIButton*)sender{
    sender.selected = !sender.selected;
    
    [self changeStartButtonText];
}

- (void) actionOctarinButton:(UIButton*)sender{
    sender.selected = !sender.selected;
    
    [self changeStartButtonText];
}

- (void) actionLevelChanged:(UISegmentedControl*)sender{
    [self changeStartButtonText];
}


#pragma mark - Timer

//подготовка таймера
-(void)start{
    
    self.seconds = [self.startButton.titleLabel.text integerValue];
    
    //подготовка звука для воспроизведения
    NSString* path = [[NSBundle mainBundle] pathForResource:@"jug_respawn_02.mp3" ofType:nil];
    NSURL* file = [NSURL fileURLWithPath:path];
    self.audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:file error:nil];
    [self.audioPlayer prepareToPlay];
    
    [self.timer invalidate];
    //self.timer=[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timerFired:)
    //                                          userInfo:nil repeats:YES];
    
    self.timer = [NSTimer timerWithTimeInterval:1
                                             target:self
                                       selector:@selector(timerFired:)
                                           userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}

//запуск таймера
-(void)timerFired:(NSTimer*)sender {
    
    //таймер тикает
    if(self.seconds > 1){

        self.seconds--;
        self.startButton.titleLabel.text = [NSString stringWithFormat:@"%ld", (long)self.seconds];
    
    //таймер подошел к концу
    }else{
        
        [self.timer invalidate];
        [self.audioPlayer play];
        
        self.startButton.selected = NO;
        [self changeStartButtonText];
        
        
    }
}

@end























