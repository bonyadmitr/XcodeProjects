//
//  ViewController.h
//  DrawTest
//
//  Created by zdaecqze zdaecq on 07.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *textField1;
@property (weak, nonatomic) IBOutlet UIView *view1;
@property (weak, nonatomic) IBOutlet UISlider *sliderLineWidth;

- (IBAction)actionButtonOK:(UIButton *)sender;
- (IBAction)actionSliderValueChanged:(UISlider *)sender;
@end

