//
//  ViewController.m
//  DrawTest
//
//  Created by zdaecqze zdaecq on 07.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"
#import "ZZDrawView.h"

@interface ViewController ()

@property (strong, nonatomic) CAShapeLayer* shapeLayer;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //self.view.multipleTouchEnabled = YES;
}

#pragma mark - Actions

- (IBAction)actionButtonOK:(UIButton *)sender {
    
    CGFloat pointRadius = self.sliderLineWidth.value;
    CGRect square = CGRectMake(CGRectGetMidX(self.view1.bounds) + [self.textField1.text floatValue] - pointRadius/2,
                               CGRectGetMidY(self.view1.bounds) - [self.textField1.text floatValue] - pointRadius/2,
                               pointRadius, pointRadius);
    
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:square];
    
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.path = [path CGPath];
    shapeLayer.strokeColor = [[UIColor redColor] CGColor];
    shapeLayer.lineWidth = pointRadius;
    shapeLayer.fillColor = [[UIColor clearColor] CGColor];
    
    [self.shapeLayer removeFromSuperlayer];

    [self.view1.layer addSublayer:shapeLayer];
    self.shapeLayer = shapeLayer;
}


- (IBAction)actionSliderValueChanged:(UISlider *)sender {
    
    [self actionButtonOK:nil];
    
}


#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    [self actionButtonOK:nil];
    return YES;
}


#pragma mark - Touches

-(void) logTouch:(NSSet*)touchSet withMethodName:(NSString*) methodName{
    
    NSMutableString* string = [NSMutableString stringWithString:methodName];
    CGPoint touchPoint;
    for (UITouch* touch in touchSet){
        touchPoint = [touch locationInView:self.view];
        [string appendFormat:@" %@", NSStringFromCGPoint(touchPoint)];
    }
    
    NSLog(@"%@",string);
}


- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(nullable UIEvent *)event{
    [self logTouch:touches withMethodName:@"touchesMoved"];
    
    UITouch* touch = [touches anyObject];
    CGPoint touchPoint = [touch locationInView:self.view1];
    
    CGFloat pointRadius = self.sliderLineWidth.value;
    
    CGRect square = CGRectMake(touchPoint.x - pointRadius/2,
                               touchPoint.y - pointRadius/2,
                               pointRadius, pointRadius);
    
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:square];
    
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.path = [path CGPath];
    shapeLayer.strokeColor = [[UIColor redColor] CGColor];
    shapeLayer.lineWidth = pointRadius;
    
    [self.view1.layer addSublayer:shapeLayer];
    
    
    // рисование с помощью линии
//    UITouch* touch = [touches anyObject];
//    CGPoint touchPoint = [touch locationInView:self.view1];
//    
//    CGFloat pointRadius = self.sliderLineWidth.value;
//    
//    UIBezierPath *path = [UIBezierPath bezierPath];
//    [path moveToPoint:self.tempPoint];
//    [path addLineToPoint:touchPoint];
//    
//    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
//    shapeLayer.path = [path CGPath];
//    shapeLayer.strokeColor = [[UIColor redColor] CGColor];
//    shapeLayer.lineWidth = pointRadius;
//    
//    [self.view1.layer addSublayer:shapeLayer];
//    self.tempPoint = touchPoint;
}
























@end
