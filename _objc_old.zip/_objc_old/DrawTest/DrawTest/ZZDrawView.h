//
//  ZZDrawView.h
//  DrawTest
//
//  Created by zdaecqze zdaecq on 07.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZZDrawView : UIView

@end
