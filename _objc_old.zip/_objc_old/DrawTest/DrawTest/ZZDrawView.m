//
//  ZZDrawView.m
//  DrawTest
//
//  Created by zdaecqze zdaecq on 07.02.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ZZDrawView.h"

@implementation ZZDrawView


-(void)drawRect:(CGRect)rect{

    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
//    CGRect square1 = CGRectMake(20, 20, 50, 50);
//    CGRect square2 = CGRectMake(70, 70, 50, 50);
//    CGRect square3 = CGRectMake(120, 120, 50, 50);
//    
//    // рисование квадратов
//    CGContextAddRect(context, square1);
//    CGContextAddRect(context, square2);
//    CGContextAddRect(context, square3);
//    CGContextSetStrokeColorWithColor(context, [UIColor blueColor].CGColor);
//    CGContextStrokePath(context);
    

    // установка свойств отрисовки
    CGContextSetLineWidth(context, 3);
    CGContextSetLineCap(context, kCGLineCapSquare);
    CGContextSetStrokeColorWithColor(context, [UIColor blackColor].CGColor);
    
    // рисование вертикальной линии
    CGContextMoveToPoint(context, CGRectGetMidX(self.bounds), CGRectGetMinY(self.bounds));
    CGContextAddLineToPoint(context, CGRectGetMidX(self.bounds), CGRectGetMaxY(self.bounds));
    
    // рисование горизонтальной линии
    CGContextMoveToPoint(context, CGRectGetMinX(self.bounds), CGRectGetMidY(self.bounds));
    CGContextAddLineToPoint(context, CGRectGetMaxX(self.bounds), CGRectGetMidY(self.bounds));
    
    // добавление линий на экран
    CGContextStrokePath(context);

}















@end
