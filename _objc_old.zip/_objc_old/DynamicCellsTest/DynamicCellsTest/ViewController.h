//
//  ViewController.h
//  DynamicCellsTest
//
//  Created by zdaecqze zdaecq on 24.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDataSource>

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

