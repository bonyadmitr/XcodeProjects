//
//  ViewController.m
//  DynamicCellsTest
//
//  Created by zdaecqze zdaecq on 24.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

}

#pragma mark UITableViewDataSource


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    NSLog(@"numberOfSectionsInTableView");
    
    NSArray* fontFamilyNamesArray = [UIFont familyNames];
    
    
    return [fontFamilyNamesArray count];
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    NSArray* fontFamilyNamesArray = [UIFont familyNames];
    NSString* fontFamilyName  = [fontFamilyNamesArray objectAtIndex:section];
    
    return fontFamilyName;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSLog(@"numberOfRowsInSection %d", section);
    
    NSArray* fontFamilyNamesArray = [UIFont familyNames];
    NSString* fontFamilyName  = [fontFamilyNamesArray objectAtIndex:section];
    
    NSArray* fontNamesForFamilyNameArray = [UIFont fontNamesForFamilyName:fontFamilyName];

    
    return [fontNamesForFamilyNameArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString* indentefier = @"Cell";
    
    //UITableViewCell* cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentefier];
    
    // переиспользование ячеек а не созднание новых. создаются только 11 для начального отображения
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:indentefier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentefier];
        NSLog(@"cell created");
    } else {
        NSLog(@"cell reused");
    }
    
    
    NSArray* fontFamilyNamesArray = [UIFont familyNames];
    NSString* fontFamilyName  = [fontFamilyNamesArray objectAtIndex:indexPath.section];
    
    NSArray* fontNamesForFamilyNameArray = [UIFont fontNamesForFamilyName:fontFamilyName];
    NSString* fontName = [fontNamesForFamilyNameArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = fontName;
    
    UIFont* font = [UIFont fontWithName:fontName size:16];
    cell.textLabel.font = font;
    
    return cell;
}


@end
