//
//  ViewController.m
//  DynamicCellsTest
//
//  Created by zdaecqze zdaecq on 24.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (strong, nonatomic) NSArray* classNames;
@property (strong, nonatomic) NSArray* classesList;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    
}

-(void) loadView{
    [super loadView];
    
    NSArray* classA = [NSArray arrayWithObjects:@"Иван Иванов",
                                                @"Анастасия Листопадова",
                                                @"Сергей Сыроежкин",
                                                @"Антон Иванов",
                                                @"Коза Листопадова",
                                                @"Алексей Сыроежкин"
                                                @"111 Иванов",
                                                @"222 Листопадова",
                                                @"333 Сыроежкин",nil];
    
    NSArray* classB = [NSArray arrayWithObjects:@"Антон Сыроежкин",
                                                @"Вера Листьева",
                                                @"Иван Сыроежкин",
                                                @"Иван Иванов",
                                                @"Анастасия Листопадова",
                                                @"Сергей Сыроежкин",
                                                @"Антон Иванов",
                                                @"Коза Листопадова",
                                                @"Алексей Сыроежкин"
                                                @"111 Иванов",
                                                @"222 Листопадова",
                                                @"333 Сыроежкин",
                                                @"Иван Иванов",
                                                @"Анастасия Листопадова",
                                                @"Сергей Сыроежкин",
                                                @"Антон Иванов",
                                                @"Коза Листопадова",
                                                @"Алексей Сыроежкин"
                                                @"111 Иванов",
                                                @"222 Листопадова",
                                                @"333 Сыроежкин",nil];
    
    self.classesList = [NSArray arrayWithObjects:classA, classB, nil];
    
    self.classNames = [NSArray arrayWithObjects:@"Класс А",
                                                @"Класс В", nil];
}

#pragma mark UITableViewDataSource


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    NSLog(@"numberOfSectionsInTableView");
    
    return [self.classesList count];
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    
    NSString* className  = [self.classNames objectAtIndex:section];
    
    return className;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSLog(@"numberOfRowsInSection %d", section);
    
    NSArray* class = [self.classesList objectAtIndex:section];
    
    return [class count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString* indentefier = @"Cell";
    
    //UITableViewCell* cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentefier];
    
    // переиспользование ячеек а не созднание новых. создаются только 11 для начального отображения
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:indentefier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentefier];
        NSLog(@"cell created");
    } else {
        NSLog(@"cell reused");
    }
    
    NSArray* class = [self.classesList objectAtIndex:indexPath.section];
    NSString* studentName = [class objectAtIndex:indexPath.row];
    
    cell.textLabel.text = studentName;
    
    return cell;
}


@end
