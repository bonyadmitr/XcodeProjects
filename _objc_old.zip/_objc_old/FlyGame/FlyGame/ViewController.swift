//
//  ViewController.swift
//  FlyGame
//
//  Created by zdaecqze zdaecq on 31.05.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var flyObject: UIView!
    
    var timer = NSTimer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if !UIAccessibilityIsReduceTransparencyEnabled() {
            self.view.backgroundColor = UIColor.clearColor()
            
            let blurEffect = UIBlurEffect(style: UIBlurEffectStyle.Dark)
            let blurEffectView = UIVisualEffectView(effect: blurEffect)
            //always fill the view
            blurEffectView.frame = self.view.bounds
            blurEffectView.autoresizingMask = [.FlexibleWidth, .FlexibleHeight]
            
            self.view.addSubview(blurEffectView) //if you have more UIViews, use an insertSubview API to place it where needed
        } 
        else {
            self.view.backgroundColor = UIColor.blackColor()
        }
        
        
        timer = NSTimer.scheduledTimerWithTimeInterval(0.01, target: self, selector: #selector(ViewController.timeUp), userInfo: nil, repeats: true)
        
        NSRunLoop.mainRunLoop().addTimer(timer, forMode: NSRunLoopCommonModes)
        //timer.fire()
    }

    @IBAction func actionGestureTap(sender: UITapGestureRecognizer) {


    }
    @IBAction func actionPanGesture(sender: UIPanGestureRecognizer) {
        
        timer.invalidate()
        if (sender.state == .Began) {
            timer = NSTimer.scheduledTimerWithTimeInterval(0.01, target: self, selector: #selector(ViewController.timeDown), userInfo: nil, repeats: true)
        }
        else if (sender.state == .Ended) {
            timer = NSTimer.scheduledTimerWithTimeInterval(0.01, target: self, selector: #selector(ViewController.timeUp), userInfo: nil, repeats: true)
        }
    }
    
    @IBAction func actionLongPress(sender: UILongPressGestureRecognizer) {
        

        
        

    }
    
    func timeUp() {
        let center = self.flyObject.center
        UIView.animateWithDuration(0.5) {
            self.flyObject.center = CGPoint(x: center.x, y: center.y + 1.5)
            
        }
    }
    
    func timeDown() {
        let center = self.flyObject.center
        UIView.animateWithDuration(0.5) {
            self.flyObject.center = CGPoint(x: center.x, y: center.y - 1.5)
            
        }
    }

}

