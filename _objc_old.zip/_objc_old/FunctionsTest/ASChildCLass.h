//
//  ASChildCLass.h
//  FunctionsTest
//
//  Created by zdaecqze zdaecq on 13.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASParantClass.h"

@interface ASChildCLass : ASParantClass

-(int) aNumber;

@end
