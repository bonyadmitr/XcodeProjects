//
//  ASChildCLass.m
//  FunctionsTest
//
//  Created by zdaecqze zdaecq on 13.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASChildCLass.h"

@implementation ASChildCLass

- (id)init
{
    self = [super init];
    if (self) {
        NSLog(@"Child initialization");
    }
    return self;
}

+(void) whoAreYou
{
    NSLog(@"I am a child");
}


- (NSString*) saySomething
{
    return @"Agu agu";
}

-(int) giveMeNumber
{
    return 123;
}

-(int) aNumber
{
    return [self giveMeNumber];
}

@end
