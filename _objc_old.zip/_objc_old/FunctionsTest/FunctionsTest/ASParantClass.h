//
//  ASParantClass.h
//  FunctionsTest
//
//  Created by zdaecqze zdaecq on 11.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASParantClass : NSObject

+(void) whoAreYou;
-(void) whoAreYou1;
-(void) SayHello;
-(void) say: (NSString*) string;
-(void) say:(NSString *)string and:(NSString*)string2;
-(NSString*) saySomething;
@property (strong, atomic) NSString* sss;

@end
