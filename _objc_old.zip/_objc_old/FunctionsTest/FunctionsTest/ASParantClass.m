//
//  ASParantClass.m
//  FunctionsTest
//
//  Created by zdaecqze zdaecq on 11.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASParantClass.h"

@implementation ASParantClass

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSLog(@"Parant initialization");
    }
    return self;
}

+(void) whoAreYou
{
    NSLog(@"I am ASParantClass");
}

-(void) whoAreYou1
{
    NSLog(@"ASParantClass %@", [self sss]);
}

-(void) SayHello
{
    NSLog(@"Hello World from parrant!");
}

-(void) say:(NSString *)string
{
    NSLog(@"%@ %@", string, [self sss]);
}

-(void) say:(NSString *)string and:(NSString*)string2
{
    NSLog(@"%@, %@", string, string2);
}

-(NSString*) sayDateInString
{
    return [NSString stringWithFormat:@"%@", [NSDate date]];
}

-(NSString*) saySomething
{
    NSString* string = [self sayDateInString];
    return string;
}


@end
