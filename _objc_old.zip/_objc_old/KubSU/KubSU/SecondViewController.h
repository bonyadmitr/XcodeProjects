//
//  SecondViewController.h
//  KubSU
//
//  Created by zdaecqze zdaecq on 05.03.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController


@end

