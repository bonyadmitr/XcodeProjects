//
//  ZZNewsController.h
//  KubSU
//
//  Created by zdaecqze zdaecq on 05.03.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZZNewsController : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@property (weak, nonatomic) IBOutlet UIButton *buttonWebBack;
@property (weak, nonatomic) IBOutlet UIButton *buttonWebForward;
@property (weak, nonatomic) IBOutlet UIButton *buttonWebRefresh;

@end
