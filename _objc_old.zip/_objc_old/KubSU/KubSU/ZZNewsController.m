//
//  ZZNewsController.m
//  KubSU
//
//  Created by zdaecqze zdaecq on 05.03.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ZZNewsController.h"
//#import <QuartzCore/QuartzCore.h> для слоев

@implementation ZZNewsController



- (void)viewDidLoad {
    [super viewDidLoad];
    
    //загрузка сайта
    NSString* string = @"https://vk.com/info_matfaka";
    NSURL* url = [NSURL URLWithString:string];
    NSURLRequest* urlRequest = [NSURLRequest requestWithURL:url];
    [self.webView loadRequest:urlRequest];
    
    self.webView.scalesPageToFit = YES; //возможность увеличения
    
    //подписание на уведмление изменении истории переходов
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(notificationWebViewHistoryDidChange:)
                                                 name:@"WebHistoryItemChangedNotification"
                                               object:nil];
    
    //кнопки недостопны при запуске
    self.buttonWebBack.enabled = [self.webView canGoBack];
    self.buttonWebForward.enabled = [self.webView canGoForward];
    
    //установка действия для кнопок
    [self.buttonWebBack addTarget:self action:@selector(actionWebBack:) forControlEvents:UIControlEventTouchUpInside];
    [self.buttonWebForward addTarget:self action:@selector(actionWebForward:) forControlEvents:UIControlEventTouchUpInside];
    [self.buttonWebRefresh addTarget:self action:@selector(actionWebRefresh:) forControlEvents:UIControlEventTouchUpInside];
    
    //установка внешнего вида кнопок
    [self setBorders:self.buttonWebBack];
    [self setBorders:self.buttonWebForward];
    [self setBorders:self.buttonWebRefresh];
    
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //отписаться от уведмления
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"WebHistoryItemChangedNotification" object:nil];
    
    //очистка кэша
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    
    NSURLCache *sharedCache = [[NSURLCache alloc] initWithMemoryCapacity:0 diskCapacity:0 diskPath:nil];
    [NSURLCache setSharedURLCache:sharedCache];
}

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    [[NSURLCache sharedURLCache] removeAllCachedResponses]; //очистка кэша
}



#pragma mark - Methods

-(void) refreshWebButtons{
    //установка доступности кнопок
    self.buttonWebBack.enabled = [self.webView canGoBack];
    self.buttonWebForward.enabled = [self.webView canGoForward];
}

-(void) setBorders:(UIView*) view {
    
    //свойства рамки
    view.layer.cornerRadius     = CGRectGetWidth(view.frame) / 2;
    view.layer.borderWidth      = 0.1f;
    view.layer.borderColor      = [UIColor darkGrayColor].CGColor;
    //view.layer.masksToBounds = NO;
    //[UIColor colorWithRed:0 green:0.478431 blue:1.0 alpha:1.0].CGColor; // синий цвет кнопок
    
    //свойства тени
    view.layer.shadowRadius     = 3;
    view.layer.shadowColor      = [UIColor darkGrayColor].CGColor;
    view.layer.shadowOffset     = CGSizeMake(0.5f, 0.5f);
    view.layer.shadowOpacity    = 0.8f;
    //view.layer.masksToBounds = NO;
    
    //для тени
    //UIEdgeInsets shadowInsets   = UIEdgeInsetsMake(0, 0, 0, 0);
    //UIBezierPath *shadowPath    = [UIBezierPath bezierPathWithOvalInRect:UIEdgeInsetsInsetRect(view.bounds, shadowInsets)];
    
    //UIBezierPath *shadowPath    = [UIBezierPath bezierPathWithOvalInRect:view.bounds];
    //view.layer.shadowPath       = shadowPath.CGPath;
}



#pragma mark - Notifications

- (void)notificationWebViewHistoryDidChange:(NSNotification*)sender{
    [self refreshWebButtons]; //обновление кнопок
}



#pragma mark - Actions

- (void)actionWebBack:(UIBarButtonItem *)sender {
    [self.webView goBack]; //переход назад по истории
}


- (void)actionWebForward:(UIBarButtonItem *)sender {
    [self.webView goForward]; //переход вперед по истории
}



- (void)actionWebRefresh:(UIBarButtonItem *)sender {
    [self.webView reload];
}



#pragma mark - UIWebViewDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView{
    [self.activityIndicator startAnimating]; //запуск индикатора загрузки
}

- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [self.activityIndicator stopAnimating]; //остановка индикатора загрузки
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error{
    [self.activityIndicator stopAnimating]; //остановка индикатора загрузки из-за ошибки
}

/*
 - (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
 
 return YES;
 }
 */

@end
