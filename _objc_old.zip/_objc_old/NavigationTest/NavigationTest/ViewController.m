//
//  ViewController.m
//  NavigationTest
//
//  Created by zdaecqze zdaecq on 05.03.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"
#import "ZZBlockObject.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    UIButton* button = [UIButton buttonWithType:UIButtonTypeCustom];
    UIImage* image = [UIImage imageNamed:@"iTunesArtwork@2x.png"];
    [button setImage:image forState:UIControlStateNormal];
    //button.frame =  CGRectMake(0, 0, image.size.width, image.size.height);
    [button sizeToFit];
    
    [button setTitle:@"111" forState:UIControlStateNormal];
    //[button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    
    //self.navigationItem.titleView = button;
    self.navigationController.navigationBar.topItem.titleView = button;
    self.navigationItem.title = @"Hello";
    //[self.view addSubview:button];
    
    
    ZZBlockObject* object = [[ZZBlockObject alloc] init];
    
    object.block = ^{
        NSLog(@"Hello");
    };
    object.block();
    
    object.anotherBlock = ^{
        NSLog(@"Hey");
    };
    object.anotherBlock();
    
    
    
    
}


@end
