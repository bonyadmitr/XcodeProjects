//
//  ZZBlockObject.h
//  NavigationTest
//
//  Created by zdaecqze zdaecq on 05.03.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void(^MyBlock)(void);

@interface ZZBlockObject : NSObject

@property (nonatomic, copy) MyBlock block;
@property (nonatomic, copy) void(^anotherBlock)(void);

@end
