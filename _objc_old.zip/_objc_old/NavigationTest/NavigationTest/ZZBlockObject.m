//
//  ZZBlockObject.m
//  NavigationTest
//
//  Created by zdaecqze zdaecq on 05.03.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ZZBlockObject.h"

@implementation ZZBlockObject

@end
