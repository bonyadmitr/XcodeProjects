//
//  ViewController.h
//  NotificationsTest2
//
//  Created by zdaecqze zdaecq on 23.03.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSString* const ZZTestPropertyDidChangedNotification;

extern NSString* const ZZTestPropertyUserInfoKey;

@interface ViewController : UIViewController


@end

