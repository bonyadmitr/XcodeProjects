//
//  ViewController.m
//  NotificationsTest2
//
//  Created by zdaecqze zdaecq on 23.03.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"
#import "ZZObject.h"


NSString* const ZZTestPropertyDidChangedNotification = @"ZZTestPropertyNotification";

NSString* const ZZTestPropertyUserInfoKey = @"ZZTestPropertyUserInfoKey";


@interface ViewController ()

@property (assign, nonatomic) float mainTestProperty;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.mainTestProperty = 5.0f;
    
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(testNotification:)
//                                                 name:ZZTestPropertyDidChangedNotification
//                                               object:nil];
    
    
    
    ZZObject* object1 = [[ZZObject alloc] init];
    object1.testProperty = 30;
    
    
    NSLog(@"object1.testProperty = %f", object1.testProperty);
    self.mainTestProperty = 15;
    NSLog(@"object1.testProperty = %f", object1.testProperty);
    
    
    //----------------------------------------------------------------
    
    
    [self addObserver:self forKeyPath:@"mainTestProperty"
              options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld
              context:nil];
    
    self.mainTestProperty = 5;
    NSLog(@"self.mainTestProperty = %f", self.mainTestProperty);
    NSLog(@"object1.testProperty = %f", object1.testProperty);
    
    
}

-(void) setMainTestProperty:(float)mainTestProperty{
    
    _mainTestProperty = mainTestProperty;
    
    NSDictionary* dictionary = [NSDictionary dictionaryWithObject:@(mainTestProperty)
                                                           forKey:ZZTestPropertyUserInfoKey];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:ZZTestPropertyDidChangedNotification
                                                        object:nil
                                                      userInfo:dictionary];
    
}

- (void)dealloc
{
    [self removeObserver:self forKeyPath:@"stringTest"];
    //[[NSNotificationCenter defaultCenter] removeObserver:self forKeyPath:ZZTestPropertyDidChangedNotification];
}

#pragma mark - Observing

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if ([keyPath isEqualToString: @"mainTestProperty"]) {
        NSLog(@"mainTestProperty changed");
    }
    
    NSLog(@"\nobserveValueForKeyPath:%@ \nofObject:%@ \nchange:%@", keyPath, object, change);
    
    id value = [change objectForKey:NSKeyValueChangeNewKey];
    NSLog(@"new value from observeDictionary: %@", value);
    
}

#pragma mark - Notifications
/*
-(void) testNotification: (NSNotification*) notification{
    
    NSLog(@"testNotification: %@", notification.userInfo);
}
*/



@end
