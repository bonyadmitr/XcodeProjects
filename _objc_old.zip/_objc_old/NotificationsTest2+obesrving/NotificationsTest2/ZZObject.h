//
//  ZZObject.h
//  NotificationsTest2
//
//  Created by zdaecqze zdaecq on 23.03.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZZObject : NSObject

@property (assign, nonatomic) float testProperty;

@end
