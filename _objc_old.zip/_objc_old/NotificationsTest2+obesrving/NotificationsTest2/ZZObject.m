//
//  ZZObject.m
//  NotificationsTest2
//
//  Created by zdaecqze zdaecq on 23.03.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ZZObject.h"
#import "ViewController.h"

@implementation ZZObject


- (instancetype)init
{
    self = [super init];
    if (self) {
        
        _testProperty = 10.0f;
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(objectTestNotification:) name:ZZTestPropertyDidChangedNotification object:nil];
        
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}


-(void) objectTestNotification: (NSNotification*) notification{
    
    NSNumber* number = [notification.userInfo objectForKey:ZZTestPropertyUserInfoKey];
    _testProperty = [number floatValue];
}

@end
