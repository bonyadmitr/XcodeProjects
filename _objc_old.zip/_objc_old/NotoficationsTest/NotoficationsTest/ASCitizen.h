//
//  ASCitizen.h
//  NotoficationsTest
//
//  Created by zdaecqze zdaecq on 29.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ASCitizen : NSObject

@property (assign, nonatomic) float salary;
@property (strong, nonatomic) NSString* name;

@end
