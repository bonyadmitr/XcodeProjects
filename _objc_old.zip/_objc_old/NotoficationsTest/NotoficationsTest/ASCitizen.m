//
//  ASCitizen.m
//  NotoficationsTest
//
//  Created by zdaecqze zdaecq on 29.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASCitizen.h"
#import "ASGovernment.h"

@implementation ASCitizen

#pragma mark - Inisialization

- (instancetype)init
{
    self = [super init];
    if (self) {
        _name = @"DefaultName";
        
        NSNotificationCenter* nc = [NSNotificationCenter defaultCenter];
        [nc addObserver:self selector:@selector(citizenSalaryChanged:)
                   name:ASGovernmentSalaryDidChangedNotification object:nil];
    }
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    //[[NSNotificationCenter defaultCenter] removeObserver:self forKeyPath:ASGovernmentSalaryDidChangedNotification];
}

#pragma mark - Notifications

-(void)citizenSalaryChanged: (NSNotification*) notification
{
    NSNumber* value = [notification.userInfo objectForKey:ASGovernmentSalaryUserInfoKey];
    float salary = [value floatValue];
    if (salary < 500) {
        NSLog(@"Citizen %@ go for REBEL!!!", self.name);
    } else if (salary > self.salary){
        NSLog(@"Citizen %@ are happy!", self.name);
    } else{
        NSLog(@"Citizen %@ are NOT happy!", self.name);
    }
        
    self.salary = salary;

}

@end
