//
//  ASGovernment.h
//  NotoficationsTest
//
//  Created by zdaecqze zdaecq on 28.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString* const ASGovernmentTaxLevelDidChangedNotification;
extern NSString* const ASGovernmentSalaryDidChangedNotification;
extern NSString* const ASGovernmentPensiyaDidChangedNotification;
extern NSString* const ASGovernmentPriceDidChangedNotification;

extern NSString* const ASGovernmentTaxLevelUserInfoKey;
extern NSString* const ASGovernmentSalaryUserInfoKey;
extern NSString* const ASGovernmentPensiyaUserInfoKey;
extern NSString* const ASGovernmentPriceUserInfoKey;


@interface ASGovernment : NSObject

@property (assign, nonatomic) float taxLevel;
@property (assign, nonatomic) float pensiya;
@property (assign, nonatomic) float price;
@property (assign, nonatomic) float salary;

@end
