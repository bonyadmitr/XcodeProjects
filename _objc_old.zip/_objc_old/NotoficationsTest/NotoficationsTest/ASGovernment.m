//
//  ASGovernment.m
//  NotoficationsTest
//
//  Created by zdaecqze zdaecq on 28.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASGovernment.h"

NSString* const ASGovernmentTaxLevelDidChangedNotification = @"ASGovernmentTaxLevelDidChangedNotification";
NSString* const ASGovernmentSalaryDidChangedNotification = @"ASGovernmentSalaryDidChangedNotification";
NSString* const ASGovernmentPensiyaDidChangedNotification = @"ASGovernmentPensiyaDidChangedNotification";
NSString* const ASGovernmentPriceDidChangedNotification = @"ASGovernmentPriceDidChangedNotification";

NSString* const ASGovernmentTaxLevelUserInfoKey = @"ASGovernmentTaxLevelUserInfoKey";
NSString* const ASGovernmentSalaryUserInfoKey = @"ASGovernmentSalaryUserInfoKey";
NSString* const ASGovernmentPensiyaUserInfoKey = @"ASGovernmentPensiyaUserInfoKey";
NSString* const ASGovernmentPriceUserInfoKey = @"ASGovernmentPriceUserInfoKey";

@implementation ASGovernment

- (instancetype)init
{
    self = [super init];
    if (self) {
        _taxLevel = 5.f;
        _salary = 1000;
        _pensiya = 500;
        _price = 10;
    }
    return self;
}

-(void) setTaxLevel:(float)taxLevel
{
    _taxLevel = taxLevel;
    
    NSDictionary* dictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                ASGovernmentTaxLevelUserInfoKey, [NSNumber numberWithFloat:taxLevel], nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:ASGovernmentTaxLevelDidChangedNotification object:nil userInfo:dictionary];
}

-(void) setSalary:(float)salary
{
    _salary = salary;
    
    NSDictionary* dictionary = [NSDictionary dictionaryWithObject:[NSNumber numberWithFloat:salary]
                                                           forKey:ASGovernmentSalaryUserInfoKey];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:ASGovernmentSalaryDidChangedNotification object:nil userInfo:dictionary];
}

-(void) setPensiya:(float)pensiya
{
    _pensiya = pensiya;
    
    NSDictionary* dictionary = [NSDictionary dictionaryWithObject:@(pensiya)
                                                           forKey:ASGovernmentPensiyaUserInfoKey];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:ASGovernmentPensiyaDidChangedNotification object:nil userInfo:dictionary];
}

-(void) setPrice:(float)price
{
    _price = price;
    
    NSDictionary* dictionary = [NSDictionary dictionaryWithObject:@(price)
                                                           forKey:ASGovernmentPriceUserInfoKey];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:ASGovernmentPriceDidChangedNotification object:nil userInfo:dictionary];
}

@end
