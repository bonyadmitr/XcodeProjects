//
//  ASBoxer.m
//  PropertyTest
//
//  Created by zdaecqze zdaecq on 14.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASBoxer.h"

// для закрытых свойств
@interface ASBoxer ()

@property (assign, nonatomic) NSInteger nameSetterCount;

@end

@implementation ASBoxer
@synthesize name = _name; // чтобы можно было переобъявить и сеттер и геттер

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.nameSetterCount = 0;
        _name = @"Qwerty123";
    }
    return self;
}

-(void) setName:(NSString *)inputName
{
    // нужно один использовать но здесь для практики два разных способа
    self.nameSetterCount++;
    _nameSetterCount++;
    
    NSLog(@"Setter name start");
    _name = inputName;
}


-(NSString*) name
{
    
    NSLog(@"Getter name start");
    NSLog(@"Setter start %d times", self.nameSetterCount);
    return _name;
}

@end

