//
//  AppDelegate.h
//  PropertyTest
//
//  Created by zdaecqze zdaecq on 14.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

