//
//  ASCock.h
//  ProtocolTest
//
//  Created by zdaecqze zdaecq on 05.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASWarrior.h"

@interface ASCock : NSObject <ASWarrior>

@property (assign, nonatomic) NSInteger age;
@property (strong, nonatomic) NSString* weapon;

@end
