//
//  ASCock.m
//  ProtocolTest
//
//  Created by zdaecqze zdaecq on 05.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ASCock.h"

@implementation ASCock

-(void) attack
{
    NSLog(@"Hit by %@", self.weapon);
}

@end
