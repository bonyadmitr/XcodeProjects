//
//  ASSettingsController.h
//  SettingsTest
//
//  Created by zdaecqze zdaecq on 22.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASSettingsController : UITableViewController

@property (weak, nonatomic) IBOutlet UITextField *textFieldLogin;
@property (weak, nonatomic) IBOutlet UITextField *textFieldPassword;
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedControlDifficult;
@property (weak, nonatomic) IBOutlet UISwitch *switchHardMode;
@property (weak, nonatomic) IBOutlet UISlider *sliderVolumeSounds;

- (IBAction)actionAnyValueChanged:(id)sender;



@end
