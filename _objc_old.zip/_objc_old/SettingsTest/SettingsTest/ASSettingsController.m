//
//  ASSettingsController.m
//  SettingsTest
//
//  Created by zdaecqze zdaecq on 22.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ASSettingsController.h"

static NSString* ASKeySettingsLogin = @"login";
static NSString* ASKeySettingsPassowrd = @"passowrd";
static NSString* ASKeySettingsDifficult = @"difficult";
static NSString* ASKeySettingsHardMode = @"hardMode";
static NSString* ASKeySettingsVolumeSounds = @"volumeSounds";

@implementation ASSettingsController

-(void) viewDidLoad{
    [super viewDidLoad];
    
    //[self.tableView setContentInset:UIEdgeInsetsMake(20, 0, 0, 0)];
    
    [self loadSettings];
}

#pragma mark - Local methods

-(void) saveSettings{
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    
    [userDefaults setObject:self.textFieldLogin.text forKey:ASKeySettingsLogin];
    [userDefaults setObject:self.textFieldPassword.text forKey:ASKeySettingsPassowrd];
    [userDefaults setInteger:self.segmentedControlDifficult.selectedSegmentIndex forKey:ASKeySettingsDifficult];
    [userDefaults setBool:self.switchHardMode.isOn forKey:ASKeySettingsHardMode];
    [userDefaults setDouble:self.sliderVolumeSounds.value forKey:ASKeySettingsVolumeSounds];
    
    [userDefaults synchronize];
    
}

-(void)loadSettings{
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    
    self.textFieldLogin.text = [userDefaults objectForKey:ASKeySettingsLogin];
    self.textFieldPassword.text = [userDefaults objectForKey:ASKeySettingsPassowrd];
    self.segmentedControlDifficult.selectedSegmentIndex = [userDefaults integerForKey:ASKeySettingsDifficult];
    self.switchHardMode.on = [userDefaults boolForKey:ASKeySettingsHardMode];
    self.sliderVolumeSounds.value = [userDefaults doubleForKey:ASKeySettingsVolumeSounds];
}

#pragma mark - Actions

- (IBAction)actionAnyValueChanged:(id)sender {
    [self saveSettings];
}

#pragma mark -  UITextFieldDelegate

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    [self saveSettings];
    
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if ([textField isEqual:self.textFieldLogin]) {
        [self.textFieldPassword becomeFirstResponder];
    } else {
        [textField resignFirstResponder];
    }
    
    return  YES;
}


@end

