//
//  ViewController.h
//  StringsTests
//
//  Created by zdaecqze zdaecq on 14.12.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

