//
//  ViewController.h
//  SumMod
//
//  Created by zdaecqze zdaecq on 28.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)countButtonTouch:(id)sender;
- (IBAction)backgroundTap:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *text1;
@property (weak, nonatomic) IBOutlet UITextField *text2;
@property (weak, nonatomic) IBOutlet UITextField *textMod;
@property (weak, nonatomic) IBOutlet UILabel *resultLabel;

@end

