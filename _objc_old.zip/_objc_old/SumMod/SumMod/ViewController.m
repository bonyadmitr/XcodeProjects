//
//  ViewController.m
//  SumMod
//
//  Created by zdaecqze zdaecq on 28.10.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)countButtonTouch:(id)sender {
    NSInteger text1IntValue = [_text1.text intValue];
    NSInteger text2IntValue = [_text2.text intValue];
    NSInteger result = (text1IntValue + text2IntValue) % [_textMod.text integerValue];
    _resultLabel.text = [@(result) stringValue];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

-(void)textFieldDidEndEditing:(UITextField *)textField {
    [self textFieldShouldReturn:textField];
}

- (IBAction)backgroundTap:(id)sender {
    //[UITextField ];
}


/*
 NSString *str = @"3 568 030";
 
 int aValue = [[str stringByReplacingOccurrencesOfString:@" " withString:@""] intValue];
 NSLog(@"%d", aValue);
 
 
 
 
 
 
 NSString *inStr = [NSString stringWithFormat: @"%ld", (long)month];
 
 NSString *inStr = [@(month) stringValue];
 */

@end
