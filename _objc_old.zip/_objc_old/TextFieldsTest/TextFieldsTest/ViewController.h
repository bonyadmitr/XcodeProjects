//
//  ViewController.h
//  TextFieldsTest
//
//  Created by zdaecqze zdaecq on 18.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *textFieldTest;
@property (weak, nonatomic) IBOutlet UITextField *textFieldTest2;

- (IBAction)actionTextFieldTestEditChanging:(UITextField *)sender;
-(IBAction)actionButtonTest:(UIButton*)sender;
- (IBAction)actionTextFieldTestEditingDidBegin:(UITextField*)sender;

@end

