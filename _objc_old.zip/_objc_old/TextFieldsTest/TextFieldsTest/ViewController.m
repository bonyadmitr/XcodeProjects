//
//  ViewController.m
//  TextFieldsTest
//
//  Created by zdaecqze zdaecq on 18.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"

@interface ViewController () <UITextFieldDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.textFieldTest becomeFirstResponder];
    self.textFieldTest2.delegate = self;
    
    NSNotificationCenter* nc = [NSNotificationCenter defaultCenter];
    
    [nc addObserver:self selector:@selector(notificationTextFieldTextDidBeginEditing:)
               name:UITextFieldTextDidBeginEditingNotification object:nil];
    [nc addObserver:self selector:@selector(notificationTextFieldTextDidEndEditing:)
               name:UITextFieldTextDidEndEditingNotification object:nil];
    [nc addObserver:self selector:@selector(notificationTextFieldTextDidChange:)
               name:UITextFieldTextDidChangeNotification object:nil];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Actions

- (IBAction)actionTextFieldTestEditChanging:(UITextField *)sender {
    NSLog(@"%@", sender.text);
}

-(IBAction)actionButtonTest:(UIButton*)sender{
    NSLog(@"TF1: %@, TF2: %@", self.textFieldTest.text, self.textFieldTest2.text);
    if ([self.textFieldTest isFirstResponder])
        [self.textFieldTest resignFirstResponder] ;
    else if ([self.textFieldTest2 isFirstResponder])
        [self.textFieldTest2 resignFirstResponder];
}

- (IBAction)actionTextFieldTestEditingDidBegin:(UITextField*)sender {
    NSLog(@"actionTextFieldTestEditingDidBegin");
}


#pragma mark - UITextFieldDelegate
/*
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    return ![textField isEqual:self.textFieldTest];
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    return NO;
}
 */

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if ([textField isEqual:self.textFieldTest]) {
        [self.textFieldTest2 becomeFirstResponder];
    } else {
        [textField resignFirstResponder];
    }
    
    return YES;    
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    NSLog(@"delegate textFieldDidBeginEditing");
}

#pragma mark - Notifications

-(void) notificationTextFieldTextDidBeginEditing:(NSNotification*) notofication{
    NSLog(@"notificationTextFieldTextDidBeginEditing");
}

-(void) notificationTextFieldTextDidEndEditing:(NSNotification*) notofication{
    NSLog(@"notificationTextFieldTextDidEndEditing");
}

-(void) notificationTextFieldTextDidChange:(NSNotification*) notofication{
    NSLog(@"notificationTextFieldTextDidChange");
}

@end
