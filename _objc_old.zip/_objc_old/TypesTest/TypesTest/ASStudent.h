//
//  ASStudent.h
//  TypesTest
//
//  Created by zdaecqze zdaecq on 02.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NSInteger Chislo;

typedef enum
{
    male = 10,
    female
} ASGender;

@interface ASStudent : NSObject

@property (strong, nonatomic) NSString* name;
@property (assign, nonatomic) ASGender gender;

@end
