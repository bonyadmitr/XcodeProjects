//
//  AppDelegate.m
//  TypesTest
//
//  Created by zdaecqze zdaecq on 02.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import "AppDelegate.h"
#import "ASStudent.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


-(void) myInc:(NSInteger)int1 pointer:(NSInteger*)int2
{
    int1++;
    //*int2 = *int2 + 1;
    (*int2)++;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    NSInteger a = 10;
    NSInteger b = a;
    NSInteger* c = &a;
    NSLog(@"a = %d, b = %d, c = %d", a, b, *c);
    b = 1;
    NSLog(@"a = %d, b = %d, c = %d", a, b, *c);
    *c = 2;
    NSLog(@"a = %d, b = %d, c = %d", a, b, *c);
    
    NSInteger int1 = 3;
    NSInteger int2 = 3;
    [self myInc:int1 pointer:&int2];
    NSLog(@"int1 = %d, int2 = %d", int1, int2);
    
    
    
    Chislo z = 5;
    
    ASStudent* student = [[ASStudent alloc] init];
    student.name = @"Ivan";
    student.gender = male;
    
    
    
    CGPoint point;
    point.x = 1.5f;
    point.y = 4.2f;
    point = CGPointMake(1, 1);
    
    CGSize size;
    size.height = 10.9f;
    size.width = 5;
    size = CGSizeMake(5, 20);
    
    CGRect rect;
    rect.origin.x = 10;
    rect.origin = point;
    rect.size = size;
    rect = CGRectMake(0, 0, 10, 30);
    
    BOOL result = CGRectContainsPoint(rect, point);
    
    char i = 'a';
    NSLog(@"i = %d, Rect is = %d, Chislo = %d", i, result, z);
    
    
    
    
    NSInteger intVar = -3;
    NSUInteger uIntVar = 5;
    BOOL boolVar = YES; //TRUE
    CGFloat floatVar = 3.3f;
    double doubleVar = 5.5f;
    
    NSNumber* intObject = [NSNumber numberWithInteger:intVar];
    NSNumber* uIntObject = [NSNumber numberWithUnsignedInteger:uIntVar];
    NSNumber* boolObject = [NSNumber numberWithBool:boolVar];
    NSNumber* floatObject = [NSNumber numberWithFloat:floatVar];
    NSNumber* doubleObject = [NSNumber numberWithDouble:doubleVar];
    
    NSArray* array = [NSArray arrayWithObjects:intObject, uIntObject, boolObject, floatObject, doubleObject, nil];
    
    NSLog(@"intObject = %d, uIntObject = %d, boolObject = %d, floatObject = %f, doubleObject = %f",
          [[array objectAtIndex:0] integerValue],
          [[array objectAtIndex:1] unsignedIntegerValue],
          [[array objectAtIndex:2] boolValue],
          [[array objectAtIndex:3] floatValue],
          [[array objectAtIndex:4] doubleValue]);
    
    
    
    CGPoint point1 = CGPointMake(0, 0);
    CGPoint point2 = CGPointMake(3, 0);
    CGPoint point3 = CGPointMake(0, 5);
    CGPoint point4 = CGPointMake(2, 3);
    CGPoint point5 = CGPointMake(5, 5);
    
    NSArray* array2 = [NSArray arrayWithObjects:
                      [NSValue valueWithCGPoint:point1],
                      [NSValue valueWithCGPoint:point2],
                      [NSValue valueWithCGPoint:point3],
                      [NSValue valueWithCGPoint:point4],
                      [NSValue valueWithCGPoint:point5],
                      nil];
    
    for (NSValue* value in array2) {
        CGPoint p = [value CGPointValue];
        NSLog(@"point = %@", NSStringFromCGPoint(p));
    }

    
    
    
    int a1 = 32;
    int a2 = 12;
    NSNumber* a1Object = [NSNumber numberWithInt:a1];
    NSNumber* a2Object = [NSNumber numberWithInt:a2];
    
    NSArray* aArray = [NSArray arrayWithObjects:a1Object, a2Object, nil];
    for (NSNumber* chislo in aArray) {
        NSLog(@"test int objects: %@", chislo);
    }
    
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
