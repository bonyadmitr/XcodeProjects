//
//  ViewController.h
//  TypesTest
//
//  Created by zdaecqze zdaecq on 02.11.15.
//  Copyright © 2015 zdaecqze zdaecq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

