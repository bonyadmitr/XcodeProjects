//
//  ViewController.m
//  ViewsTest
//
//  Created by zdaecqze zdaecq on 10.01.16.
//  Copyright © 2016 zdaecqze zdaecq. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIView* view1 = [[UIView alloc] initWithFrame:CGRectMake(100, 100, 100, 100)];
    view1.backgroundColor = [[UIColor redColor] colorWithAlphaComponent:0.8f];
    view1.autoresizingMask = UIViewAutoresizingFlexibleWidth |
                            UIViewAutoresizingFlexibleHeight |
                            UIViewAutoresizingFlexibleBottomMargin |
                            UIViewAutoresizingFlexibleRightMargin;
    [self.view addSubview:view1];
    
    UIView* view2 = [[UIView alloc] initWithFrame:CGRectMake(50, 50, 100, 300)];
    view2.backgroundColor = [[UIColor greenColor] colorWithAlphaComponent:0.8f];
    [self.view addSubview:view2];
    
    [self.view bringSubviewToFront:view1];
}

- (void)viewWillLayoutSubviews {
    
    [super viewWillLayoutSubviews];
    
    CGRect rect;
    //rect.origin.x = CGRectGetWidth(self.view.bounds) - 100;
    rect.origin.x = self.view.bounds.size.width - 100;
    rect.origin.y = 0;
    rect.size = CGSizeMake(100, 100);
    
    UIView* flexibleView = [[UIView alloc] initWithFrame:rect];
    [flexibleView.backgroundColor = [UIColor blueColor] colorWithAlphaComponent:0.8f];
    [self.view addSubview:flexibleView];
    
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskAll;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
